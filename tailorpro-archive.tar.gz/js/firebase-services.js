// js/firebase-services.js - Services Métier pour Firebase
console.log('🔥 firebase-services.js: Chargement des services métier');

document.addEventListener('firebase-services-ready', () => {

    if (window.firebaseServices && !window.firebaseServices.business) {

        console.log('🏗️ firebase-services.js: Initialisation des services métier...');

        class BaseManager {
            constructor(collectionName) {
                if (!collectionName) {
                    throw new Error("BaseManager requires a collectionName.");
                }
                this.collectionName = collectionName;
            }

            /**
             * Récupère la référence de la collection Firestore pour un utilisateur donné.
             * @param {string} userId L'ID de l'utilisateur.
             * @returns {firebase.firestore.CollectionReference} Référence de la collection.
             * @private
             */
            _getCollectionRef(userId) {
                if (!window.firebaseServices || !window.firebaseServices.firestore) {
                    throw new Error("Firebase Firestore service is not initialized.");
                }
                return window.firebaseServices.firestore
                    .collection('users')
                    .doc(userId)
                    .collection(this.collectionName);
            }

            /**
             * Ajoute un nouveau document à la collection de l'utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {object} data Les données du document à ajouter.
             * @returns {Promise<object>} Le document ajouté avec son ID.
             */
            async addDocument(userId, data) {
                const user = window.firebaseServices.requireAuth(`ajouter un document à ${this.collectionName}`);
                if (user.uid !== userId) {
                    throw new Error("Unauthorized: userId does not match authenticated user.");
                }
                const docRef = await this._getCollectionRef(userId).add({
                    ...data,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                });
                const snapshot = await docRef.get();
                return { id: snapshot.id, ...snapshot.data() };
            }

            /**
             * Récupère un document spécifique par son ID.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} documentId L'ID du document à récupérer.
             * @returns {Promise<object|null>} Le document ou null s'il n'existe pas.
             */
            async getDocument(userId, documentId) {
                const user = window.firebaseServices.requireAuth(`lire le document ${documentId} de ${this.collectionName}`);
                if (user.uid !== userId) {
                    throw new Error("Unauthorized: userId does not match authenticated user.");
                }
                const doc = await this._getCollectionRef(userId).doc(documentId).get();
                return doc.exists ? { id: doc.id, ...doc.data() } : null;
            }

            /**
             * Récupère tous les documents de la collection de l'utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} [orderBy='createdAt'] Le champ par lequel trier.
             * @param {string} [direction='desc'] La direction du tri ('asc' ou 'desc').
             * @returns {Promise<Array>} Une liste de tous les documents.
             */
            async getAllDocuments(userId, orderBy = 'createdAt', direction = 'desc') {
                const user = window.firebaseServices.requireAuth(`lire tous les documents de ${this.collectionName}`);
                if (user.uid !== userId) {
                    throw new Error("Unauthorized: userId does not match authenticated user.");
                }
                const snapshot = await this._getCollectionRef(userId)
                    .orderBy(orderBy, direction)
                    .get();
                return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
            }

            /**
             * Met à jour un document existant.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} documentId L'ID du document à mettre à jour.
             * @param {object} updates Les champs à mettre à jour.
             * @returns {Promise<void>}
             */
            async updateDocument(userId, documentId, updates) {
                const user = window.firebaseServices.requireAuth(`modifier le document ${documentId} de ${this.collectionName}`);
                if (user.uid !== userId) {
                    throw new Error("Unauthorized: userId does not match authenticated user.");
                }
                await this._getCollectionRef(userId).doc(documentId).update({
                    ...updates,
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                });
            }

            /**
             * Supprime un document.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} documentId L'ID du document à supprimer.
             * @returns {Promise<void>}
             */
            async deleteDocument(userId, documentId) {
                const user = window.firebaseServices.requireAuth(`supprimer le document ${documentId} de ${this.collectionName}`);
                if (user.uid !== userId) {
                    throw new Error("Unauthorized: userId does not match authenticated user.");
                }
                await this._getCollectionRef(userId).doc(documentId).delete();
            }
        }
        class CreationsManager extends BaseManager {
            constructor() {
                super('creations');
            }

            /**
             * Ajoute une nouvelle création pour l'utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {object} creationData Les données de la création à ajouter.
             * @returns {Promise<object>} La création ajoutée avec son ID.
             */
            async add(userId, creationData) {
                return this.addDocument(userId, creationData);
            }

            /**
             * Met à jour une création existante.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} creationId L'ID de la création à mettre à jour.
             * @param {object} updates Les champs à mettre à jour.
             * @returns {Promise<void>}
             */
            async update(userId, creationId, updates) {
                return this.updateDocument(userId, creationId, updates);
            }

            /**
             * Duplique une création existante.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} originalCreationId L'ID de la création originale à dupliquer.
             * @returns {Promise<object>} La nouvelle création dupliquée avec son ID.
             */
            async duplicate(userId, originalCreationId) {
                const originalCreation = await this.getDocument(userId, originalCreationId);

                if (!originalCreation) {
                    throw new Error(`Creation with ID ${originalCreationId} not found.`);
                }

                // Crée une copie des données et supprime les champs non nécessaires pour la duplication
                const duplicatedData = { ...originalCreation };
                delete duplicatedData.id; // L'ID sera généré automatiquement par Firestore
                delete duplicatedData.createdAt;
                delete duplicatedData.updatedAt;

                // Génère un nouveau code produit et un nouveau nom
                const newProductCode = `DUP-${duplicatedData.productCode}-${Date.now().toString().slice(-6)}`;
                const newName = `Copie de ${duplicatedData.name}`;

                // Met à jour les données de la création dupliquée
                duplicatedData.productCode = newProductCode;
                duplicatedData.name = newName;
                duplicatedData.status = 'draft'; // Une création dupliquée est généralement un brouillon

                return this.add(userId, duplicatedData);
            }
        }
        class ClientsManager extends BaseManager {
            constructor() {
                super('clients');
            }

            /**
             * Ajoute un nouveau client pour l'utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {object} clientData Les données du client à ajouter.
             * @returns {Promise<object>} Le client ajouté avec son ID.
             */
            async add(userId, clientData) {
                return this.addDocument(userId, clientData);
            }

            /**
             * Met à jour un client existant.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} clientId L'ID du client à mettre à jour.
             * @param {object} updates Les champs à mettre à jour.
             * @returns {Promise<void>}
             */
            async update(userId, clientId, updates) {
                return this.updateDocument(userId, clientId, updates);
            }

            /**
             * Récupère un client spécifique par son ID.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} clientId L'ID du client à récupérer.
             * @returns {Promise<object|null>} Le client ou null s'il n'existe pas.
             */
            async get(userId, clientId) {
                return this.getDocument(userId, clientId);
            }
        }

        class OrdersManager extends BaseManager {
            constructor() { super('orders'); }

            /**
             * NOUVEAU : Récupère toutes les commandes pour un client spécifique.
             * @param {string} clientId L'ID du client.
             * @returns {Promise<Array>} Une liste des commandes du client.
             */
            async getOrdersByClientId(clientId) {
                const user = window.firebaseServices.requireAuth(`lire les commandes du client ${clientId}`);
                const snapshot = await this._getCollectionRef(user.uid)
                    .where('clientId', '==', clientId)
                    .orderBy('createdAt', 'desc')
                    .get();
                return snapshot.docs.map(doc => doc.data());
            }
        }

        class MeasurementsManager extends BaseManager {
            constructor() {
                super('measurements');
            }

            /**
             * Ajoute une nouvelle mesure pour l'utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {object} measurementData Les données de la mesure à ajouter.
             * @returns {Promise<object>} La mesure ajoutée avec son ID.
             */
            async add(userId, measurementData) {
                return this.addDocument(userId, measurementData);
            }

            /**
             * Met à jour une mesure existante.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} measurementId L'ID de la mesure à mettre à jour.
             * @param {object} updates Les champs à mettre à jour.
             * @returns {Promise<void>}
             */
            async update(userId, measurementId, updates) {
                return this.updateDocument(userId, measurementId, updates);
            }

            /**
             * Récupère une mesure spécifique par son ID.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} measurementId L'ID de la mesure à récupérer.
             * @returns {Promise<object|null>} La mesure ou null s'il n'existe pas.
             */
            async get(userId, measurementId) {
                return this.getDocument(userId, measurementId);
            }
        }
        class StorageManager {
            constructor() {
                if (!window.firebaseServices || !window.firebaseServices.storage) {
                    throw new Error("Firebase Storage service is not initialized.");
                }
                this.storage = window.firebaseServices.storage;
            }

            /**
             * Télécharge un fichier vers Firebase Storage.
             * @param {string} filePath Le chemin où stocker le fichier dans Storage (par exemple, 'users/userId/images/file.jpg').
             * @param {File} file Le fichier à télécharger.
             * @param {object} [metadata] Métadonnées optionnelles pour le fichier.
             * @returns {Promise<string>} L'URL de téléchargement du fichier.
             */
            async uploadFile(filePath, file, metadata = {}) {
                const storageRef = this.storage.ref(filePath);
                const snapshot = await storageRef.put(file, metadata);
                return snapshot.ref.getDownloadURL();
            }

            /**
             * Supprime un fichier de Firebase Storage.
             * @param {string} filePath Le chemin du fichier à supprimer dans Storage.
             * @returns {Promise<void>}
             */
            async deleteFile(filePath) {
                const storageRef = this.storage.ref(filePath);
                await storageRef.delete();
            }
        }
        class BillingManager {
            constructor() {
                // Initialise un service de facturation hypothétique
                // Pour l'instant, c'est un placeholder.
                console.log("BillingManager: Initializing (placeholder for billing service).");
            }

            /**
             * Récupère les informations de facturation d'un utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @returns {Promise<object>} Les informations de facturation (factices pour l'instant).
             */
            async getBillingInfo(userId) {
                console.log(`BillingManager: Fetching billing info for user ${userId}`);
                return Promise.resolve({
                    userId: userId,
                    plan: "Premium",
                    status: "active",
                    nextBillingDate: "2024-12-01",
                    paymentMethod: "Visa **** 1234"
                });
            }

            /**
             * S'abonne à un plan de facturation.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} planId L'ID du plan à souscrire.
             * @returns {Promise<object>} Le statut de la souscription (factice pour l'instant).
             */
            async subscribeToPlan(userId, planId) {
                console.log(`BillingManager: User ${userId} subscribing to plan ${planId}`);
                return Promise.resolve({
                    success: true,
                    message: `Successfully subscribed user ${userId} to plan ${planId}.`,
                    subscriptionId: `sub_${Math.random().toString(36).substr(2, 9)}`
                });
            }

            /**
             * Met à jour un abonnement existant.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} subscriptionId L'ID de l'abonnement à mettre à jour.
             * @param {string} newPlanId Le nouvel ID du plan.
             * @returns {Promise<object>} Le statut de la mise à jour (factice pour l'instant).
             */
            async updateSubscription(userId, subscriptionId, newPlanId) {
                console.log(`BillingManager: User ${userId} updating subscription ${subscriptionId} to plan ${newPlanId}`);
                return Promise.resolve({
                    success: true,
                    message: `Successfully updated subscription ${subscriptionId} for user ${userId} to plan ${newPlanId}.`
                });
            }

            /**
             * Annule un abonnement existant.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} subscriptionId L'ID de l'abonnement à annuler.
             * @returns {Promise<object>} Le statut de l'annulation (factice pour l'instant).
             */
            async cancelSubscription(userId, subscriptionId) {
                console.log(`BillingManager: User ${userId} canceling subscription ${subscriptionId}`);
                return Promise.resolve({
                    success: true,
                    message: `Successfully canceled subscription ${subscriptionId} for user ${userId}.`
                });
            }

            /**
             * Récupère les méthodes de paiement d'un utilisateur.
             * @param {string} userId L'ID de l'utilisateur.
             * @returns {Promise<Array<object>>} Une liste des méthodes de paiement (factice pour l'instant).
             */
            async getPaymentMethods(userId) {
                console.log(`BillingManager: Fetching payment methods for user ${userId}`);
                return Promise.resolve([
                    { id: "pm_visa1234", type: "card", brand: "Visa", last4: "1234", expiry: "12/25" },
                    { id: "pm_mc5678", type: "card", brand: "Mastercard", last4: "5678", expiry: "06/27" }
                ]);
            }

            /**
             * Ajoute une nouvelle méthode de paiement.
             * @param {string} userId L'ID de l'utilisateur.
             * @param {string} token Le token de la méthode de paiement (par exemple, un token Stripe).
             * @returns {Promise<object>} Le statut de l'ajout (factice pour l'instant).
             */
            async addPaymentMethod(userId, token) {
                console.log(`BillingManager: User ${userId} adding payment method with token ${token}`);
                return Promise.resolve({
                    success: true,
                    message: `Successfully added payment method for user ${userId}.`,
                    paymentMethodId: `pm_${Math.random().toString(36).substr(2, 9)}`
                });
            }
        }

        // --- Exposition des services métier ---
        window.firebaseServices.business = {
            creations: new CreationsManager(),
            clients: new ClientsManager(),
            orders: new OrdersManager(),
            measurements: new MeasurementsManager(),
            billing: new BillingManager(),
            storage: new StorageManager()
        };

        // Pour la compatibilité
        Object.assign(window.firebaseServices, window.firebaseServices.business);
        window.firebaseServices.storageManager = window.firebaseServices.business.storage;

        console.log('✅ firebase-services.js: Services métier initialisés et attachés.');
        document.dispatchEvent(new CustomEvent('business-services-ready'));
    }
});