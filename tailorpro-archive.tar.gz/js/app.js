// js/app.js - VERSION FINALE CORRIGÉE ET AMÉLIORÉE
console.log('🚀 app.js: Chargement - Version finale améliorée');

let currentUser = null;

/**
 * Récupère l'utilisateur actuellement authentifié.
 * @returns {object|null} L'objet utilisateur Firebase ou null.
 */
function getCurrentUser() {
    return currentUser;
}

/**
 * Met à jour l'utilisateur actuel.
 * @param {object|null} user - L'objet utilisateur Firebase ou null.
 */
function setCurrentUser(user) {
    console.log('👤 app.js: Utilisateur mis à jour:', user ? user.email : 'null');
    currentUser = user;
}

/**
 * Masque la modale de formulaire active.
 */
function hideFormModal() {
    const modal = document.getElementById('form-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.innerHTML = ''; // Vider pour la prochaine utilisation
    }
}

/**
 * Masque la modale de détails active.
 */
function hideDetailsModal() {
    const modal = document.getElementById('details-modal');
    if (modal) {
        modal.style.display = 'none';
        modal.innerHTML = ''; // Vider pour la prochaine utilisation
    }
}


/**
 * Affiche une section spécifique (onglet).
 * AMÉLIORÉ: Gère mieux les utilisateurs non connectés et charge le contenu dynamiquement.
 */
async function showTab(tabName) {
    console.log(`📱 app.js: Tentative d'affichage de l'onglet: ${tabName}`);

    const user = getCurrentUser();

    if (!user && tabName !== 'dashboard') {
        console.warn(`⚠️ app.js: Accès non autorisé à "${tabName}". Redirection vers le tableau de bord.`);
        showNotification('Veuillez vous connecter pour accéder à cette section.', 'warning');
        showTab('dashboard');
        return;
    }

    document.querySelectorAll('.content-section').forEach(section => section.classList.remove('active'));
    document.querySelectorAll('nav a').forEach(link => link.classList.remove('nav-active'));

    const targetSection = document.getElementById(`${tabName}-section`);
    const targetLink = document.querySelector(`nav a[data-section="${tabName}"]`);

    if (targetSection && targetLink) {
        targetSection.classList.add('active');
        targetLink.classList.add('nav-active');

        // Vider le contenu de la section principale avant de charger le nouveau contenu
        const contentDiv = document.getElementById(`${tabName}-content`);
        if (contentDiv) {
            contentDiv.innerHTML = ''; // Réinitialiser le contenu spécifique à l'onglet
        } else {
             // Fallback: Si le div content-XXX n'est pas trouvé, vider la section entière
            targetSection.innerHTML = `<h2>${targetLink.textContent}</h2><div id="${tabName}-content"></div>`;
        }


        try {
            if (user) {
                switch(tabName) {
                    case 'dashboard': window.renderDashboard?.(user); break;
                    case 'clients': window.renderClients?.(user); break;
                    case 'orders': window.renderOrders?.(user); break;
                    case 'creations': window.renderCreations?.(user); break;
                    case 'measurements': window.renderMeasurements?.(user); break;
                    case 'finances': window.renderFinances?.(user); break;
                    case 'settings': window.renderSettings?.(user); break;
                }
            } else {
                if (tabName === 'dashboard') {
                    window.renderPublicContent?.();
                }
            }
            console.log(`✅ app.js: Onglet "${tabName}" affiché.`);
        } catch (error) {
            console.error(`❌ app.js: Erreur lors du rendu de l'onglet "${tabName}":`, error);
            showNotification(`Erreur au chargement de la section ${tabName}.`, 'error');
        }
    } else {
        console.error(`❌ app.js: Section ou lien introuvable pour "${tabName}".`);
        if(tabName !== 'dashboard') {
            showTab('dashboard'); // Fallback
        }
    }
}

/**
 * Configure les écouteurs d'événements globaux pour l'application.
 */
function setupEventListeners() {
    const mainContent = document.getElementById('main-content');
    if (mainContent) {
        mainContent.addEventListener('click', (event) => {
            const target = event.target.closest('[data-action]');
            if (!target) return;

            const { type } = target.dataset;
            
            switch (type) {
                case 'client': window.clientsUI?.handleClientActions?.(event); break;
                case 'creation': window.creationsUI?.handleCreationActions?.(event); break;
                case 'order': window.ordersUI?.handleOrderActions?.(event); break;
                case 'measurement': window.measurementsUI?.handleMeasurementActions?.(event); break;
                case 'finance':
                case 'transaction': window.financesUI?.handleFinanceActions?.(event); break;
                default: break;
            }
        });
    }

    const nav = document.querySelector('nav');
    if (nav) {
        nav.addEventListener('click', (event) => {
            if (event.target.matches('a[data-section]')) {
                event.preventDefault();
                showTab(event.target.dataset.section);
            }
        });
    }

    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
             window.firebaseServices.auth.signOut().catch(error => {
                 console.error('Erreur de déconnexion:', error);
                 showNotification('Erreur lors de la déconnexion.', 'error');
             });
        });
    }
}

// Exposition des fonctions globales
window.app = {
    showTab,
    showAppScreen: () => document.getElementById('app-container').style.display = 'block',
    showAuthScreen: () => document.getElementById('auth-container').style.display = 'block',
    initPublic: () => setCurrentUser(null),
    initPremium: (user) => setCurrentUser(user),
    getCurrentUser,
    setCurrentUser,
    showNotification,
    hideFormModal,
    hideDetailsModal
};

// Initialisation
setupEventListeners();