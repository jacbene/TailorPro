// js/ui/render.js - Fonctions de rendu améliorées et sécurisées
console.log('🎨 render.js: Chargement - Version améliorée et sécurisée');

/**
 * Affiche le contenu public pour les utilisateurs non connectés.
 */
function renderPublicContent() {
    const dashboardSection = document.getElementById('dashboard-section');
    if (!dashboardSection) return;

    dashboardSection.innerHTML = `
        <h2>Bienvenue sur TailorPro</h2>
        <div class="public-dashboard">
            <p>Votre solution de gestion d'entreprise de couture tout-en-un.</p>
            <p>Connectez-vous pour accéder à votre tableau de bord et gérer vos clients, commandes et créations.</p>
            <button id="login-button" class="btn btn-primary">Se connecter ou créer un compte</button>
        </div>
    `;

    const loginButton = document.getElementById('login-button');
    if (loginButton) {
        loginButton.addEventListener('click', () => {
            if (window.init && typeof window.init.showAuthInterface === 'function') {
                window.init.showAuthInterface();
            }
        });
    }
}

/**
 * Affiche le tableau de bord pour un utilisateur connecté.
 * @param {object} user - L'objet utilisateur Firebase.
 */
function renderDashboard(user) {
    const dashboardContent = document.getElementById('dashboard-content');
    if (!dashboardContent) {
        console.error("L'élément #dashboard-content est introuvable.");
        return;
    }

    if (user) {
        dashboardContent.innerHTML = `
            <div class="dashboard-header">
                <h3>Bonjour, ${user.displayName || user.email} !</h3>
                <p>Heureux de vous revoir.</p>
            </div>
            <div id="dashboard-widgets" class="widgets-container">
                <!-- Les widgets seront injectés ici -->
            </div>
        `;
        const widgetsContainer = document.getElementById('dashboard-widgets');
        if (widgetsContainer) {
            renderRecentActivityWidget(user, widgetsContainer);
        }
    } else {
        renderPublicContent();
    }
}

/**
 * Affiche le widget d'activité récente.
 * @param {object} user - L'objet utilisateur Firebase.
 * @param {HTMLElement} container - Le conteneur où injecter le widget.
 */
async function renderRecentActivityWidget(user, container) {
    if (!container) return;

    container.innerHTML = `
        <div class="widget">
            <h4>Activité Récente</h4>
            <div id="recent-activity-content">
                <p>Chargement des activités...</p>
            </div>
        </div>
    `;

    const content = document.getElementById('recent-activity-content');

    try {
        const [orders, clients] = await Promise.all([
            window.firebaseServices.orders.getAllDocuments(user.uid, 'createdAt', 'desc'),
            window.firebaseServices.clients.getAllDocuments(user.uid, 'createdAt', 'desc')
        ]);

        let activityHTML = '<ul>';

        if (orders.length > 0) {
            activityHTML += '<li><strong>Dernières commandes :</strong></li>';
            orders.slice(0, 3).forEach(order => {
                activityHTML += `<li>Commande de ${order.totalAmount} € pour ${order.clientName || 'un client'} - <span class="badge status-${order.status}">${order.status}</span></li>`;
            });
        }

        if (clients.length > 0) {
            activityHTML += '<li><strong>Nouveaux clients :</strong></li>';
            clients.slice(0, 3).forEach(client => {
                activityHTML += `<li>${client.firstName} ${client.lastName} - ${client.email || 'Email non fourni'}</li>`;
            });
        }

        if (orders.length === 0 && clients.length === 0) {
            activityHTML += '<li>Aucune activité récente à afficher.</li>';
        }

        activityHTML += '</ul>';
        content.innerHTML = activityHTML;

    } catch (error) {
        console.error("Erreur lors de la récupération de l'activité récente :", error);
        content.innerHTML = '<p>Impossible de charger l'activité récente.</p>';
    }
}


/**
 * Affiche la liste des clients pour un utilisateur connecté.
 * @param {object} user - L'objet utilisateur Firebase.
 */
async function renderClients(user) {
    const clientsSection = document.getElementById('clients-section');
    if (!clientsSection) return;

    clientsSection.innerHTML = `
        <h2>Clients</h2>
        <button class="btn btn-primary" data-action="add" data-type="client">Ajouter un client</button>
        <div id="clients-list-container" class="list-container"></div>
    `;

    const container = document.getElementById('clients-list-container');

    try {
        const clients = await window.firebaseServices.clients.getAllDocuments(user.uid);
        
        if (clients.length === 0) {
            container.innerHTML = '<p>Aucun client trouvé. Commencez par en ajouter un !</p>';
            return;
        }

        let clientRows = clients.map(client => `
            <tr>
                <td>${client.lastName || ''} ${client.firstName || ''}</td>
                <td>${client.phone || 'N/A'}</td>
                <td>${client.email || 'N/A'}</td>
                <td class="client-actions">
                    <button class="btn btn-sm btn-info" data-action="view-history" data-client-id="${client.id}">Historique</button>
                    <button class="btn btn-sm btn-outline" data-action="edit" data-type="client" data-id="${client.id}">Modifier</button>
                    <button class="btn btn-sm btn-danger" data-action="delete" data-type="client" data-id="${client.id}">Supprimer</button>
                </td>
            </tr>
        `).join('');

        container.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Téléphone</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>${clientRows}</tbody>
            </table>
        `;

    } catch (error) {
        console.error('❌ render.js: Erreur rendu clients:', error);
        container.innerHTML = '<p class="error-message">Impossible de charger les clients.</p>';
        window.app.showNotification('Erreur lors du chargement des clients', 'error');
    }
}

/**
 * Affiche la liste des créations pour un utilisateur connecté.
 * @param {object} user - L'objet utilisateur Firebase.
 */
async function renderCreations(user) {
    const creationsSection = document.getElementById('creations-section');
    if (!creationsSection) return;

    creationsSection.innerHTML = `
        <h2>Créations</h2>
        <button class="btn btn-primary" data-action="add" data-type="creation">Ajouter une création</button>
        <div id="creations-list-container" class="list-container"></div>
    `;

     const container = document.getElementById('creations-list-container');

    try {
        const creations = await window.firebaseServices.creations.getAllDocuments(user.uid);
        if (creations.length === 0) {
            container.innerHTML = '<p>Aucune création trouvée. Commencez par en ajouter une !</p>';
            return;
        }

        let creationCards = creations.map(c => `
            <div class="card creation-card">
                <img src="${c.imageUrl || './icons/icon-512.png'}" alt="${c.name}" class="card-img-top">
                <div class="card-body">
                    <h5 class="card-title">${c.name}</h5>
                    <p class="card-text">Prix: ${c.price} €</p>
                    <button class="btn btn-sm btn-outline" data-action="edit" data-type="creation" data-id="${c.id}">Modifier</button>
                </div>
            </div>
        `).join('');
        container.innerHTML = `<div class="grid">${creationCards}</div>`;

    } catch (error) {
        console.error('❌ render.js: Erreur rendu créations:', error);
        container.innerHTML = '<p class="error-message">Impossible de charger les créations.</p>';
        window.app.showNotification('Erreur lors du chargement des créations', 'error');
    }
}

/**
 * Affiche la liste des commandes pour un utilisateur connecté.
 * @param {object} user - L'objet utilisateur Firebase.
 */
async function renderOrders(user) {
    const ordersSection = document.getElementById('orders-section');
    if (!ordersSection) return;

    ordersSection.innerHTML = `
        <h2>Commandes</h2>
        <button class="btn btn-primary" data-action="add" data-type="order">Ajouter une commande</button>
        <div id="orders-list-container" class="list-container"></div>
    `;

    const container = document.getElementById('orders-list-container');

    try {
        const orders = await window.firebaseServices.orders.getAllDocuments(user.uid, 'createdAt', 'desc');
        if (orders.length === 0) {
            container.innerHTML = '<p>Aucune commande trouvée.</p>';
            return;
        }

        let orderRows = orders.map(order => `
            <tr>
                <td>${new Date(order.createdAt.seconds * 1000).toLocaleDateString()}</td>
                <td>${order.clientName || 'N/A'}</td>
                <td>${order.totalAmount} €</td>
                <td><span class="badge status-${order.status}">${order.status}</span></td>
                <td><button class="btn btn-sm btn-info" data-action="view" data-type="order" data-id="${order.id}">Détails</button></td>
            </tr>
        `).join('');

        container.innerHTML = `
            <table class="table">
                <thead><tr><th>Date</th><th>Client</th><th>Montant</th><th>Statut</th><th>Actions</th></tr></thead>
                <tbody>${orderRows}</tbody>
            </table>
        `;

    } catch (error) {
        console.error('❌ render.js: Erreur rendu commandes:', error);
        container.innerHTML = '<p class="error-message">Impossible de charger les commandes.</p>';
        window.app.showNotification('Erreur lors du chargement des commandes', 'error');
    }
}

async function renderMeasurements(user) {
    const section = document.getElementById('measurements-section');
    if (!section) return;

    section.innerHTML = `
        <h2>Mesures</h2>
        <button class="btn btn-primary" data-action="add" data-type="measurement">Ajouter une fiche de mesures</button>
        <div id="measurements-list-container" class="list-container"></div>
    `;

    const container = document.getElementById('measurements-list-container');
    container.innerHTML = '<p>Chargement des fiches de mesures...</p>';

    try {
        const [measurements, clients] = await Promise.all([
            window.firebaseServices.measurements.getAllDocuments(user.uid, 'createdAt', 'desc'),
            window.firebaseServices.clients.getAllDocuments(user.uid)
        ]);

        const clientsMap = new Map(clients.map(c => [c.id, c]));

        if (measurements.length === 0) {
            container.innerHTML = '<p>Aucune fiche de mesures trouvée. Commencez par en ajouter une !</p>';
            return;
        }

        const measurementCards = measurements.map(m => {
            const client = clientsMap.get(m.clientId);
            const clientName = client ? `${client.firstName} ${client.lastName}` : 'Client inconnu';
            const date = m.createdAt ? new Date(m.createdAt.seconds * 1000).toLocaleDateString() : 'Date inconnue';

            // Crée un aperçu des mesures
            const measuresPreview = Object.entries(m.measures || {})
                .slice(0, 3)
                .map(([key, value]) => `<span>${key}: ${value} cm</span>`)
                .join(', ');

            return `
                <div class="card measurement-card">
                    <div class="card-body">
                        <h5 class="card-title">${clientName}</h5>
                        <p class="card-subtitle mb-2 text-muted">Enregistré le : ${date}</p>
                        <div class="card-text measures-preview">${measuresPreview || 'Aucune mesure renseignée.'}</div>
                        <div class="card-actions">
                            <button class="btn btn-sm btn-info" data-action="view" data-type="measurement" data-id="${m.id}">Voir</button>
                            <button class="btn btn-sm btn-outline" data-action="edit" data-type="measurement" data-id="${m.id}">Modifier</button>
                            <button class="btn btn-sm btn-danger" data-action="delete" data-type="measurement" data-id="${m.id}">Supprimer</button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        container.innerHTML = `<div class="grid">${measurementCards}</div>`;

    } catch (error) {
        console.error('❌ render.js: Erreur rendu mesures:', error);
        container.innerHTML = '<p class="error-message">Impossible de charger les fiches de mesures.</p>';
        window.app.showNotification('Erreur lors du chargement des mesures', 'error');
    }
}

/**
 * Affiche la section des finances pour un utilisateur connecté.
 * @param {object} user - L'objet utilisateur Firebase.
 */
async function renderFinances(user) {
    const financesContent = document.getElementById('finances-content');
    if (!financesContent) {
        console.error("L'élément #finances-content est introuvable.");
        return;
    }

    financesContent.innerHTML = `
        <div class="finances-header">
            <button class="btn btn-primary" data-action="add" data-type="finance">Ajouter une transaction</button>
        </div>
        <div id="finances-summary" class="widgets-container"></div>
        <div id="transactions-list-container" class="list-container">
            <p>Chargement des transactions...</p>
        </div>
    `;

    const summaryContainer = document.getElementById('finances-summary');
    const listContainer = document.getElementById('transactions-list-container');

    try {
        const transactions = await window.firebaseServices.transactions.getAllDocuments(user.uid, 'date', 'desc');

        let totalRevenue = 0;
        let totalExpenses = 0;

        transactions.forEach(t => {
            if (t.type === 'revenu') {
                totalRevenue += t.amount;
            } else if (t.type === 'depense') {
                totalExpenses += t.amount;
            }
        });

        const balance = totalRevenue - totalExpenses;

        // Render summary
        summaryContainer.innerHTML = `
            <div class="widget">
                <h4>Revenus Totaux</h4>
                <p class="amount revenue">${totalRevenue.toFixed(2)} €</p>
            </div>
            <div class="widget">
                <h4>Dépenses Totales</h4>
                <p class="amount expense">${totalExpenses.toFixed(2)} €</p>
            </div>
            <div class="widget">
                <h4>Solde</h4>
                <p class="amount balance ${balance >= 0 ? 'revenue' : 'expense'}">${balance.toFixed(2)} €</p>
            </div>
        `;

        if (transactions.length === 0) {
            listContainer.innerHTML = '<p>Aucune transaction trouvée. Commencez par en ajouter une !</p>';
            return;
        }

        // Render transaction list
        const transactionRows = transactions.map(t => {
            const date = t.date ? new Date(t.date.seconds * 1000).toLocaleDateString() : 'N/A';
            return `
                <tr>
                    <td>${date}</td>
                    <td>${t.description}</td>
                    <td><span class="badge status-${t.type}">${t.type}</span></td>
                    <td class="amount ${t.type === 'revenu' ? 'revenue' : 'expense'}">${t.amount.toFixed(2)} €</td>
                    <td class="actions">
                        <button class="btn btn-sm btn-outline" data-action="edit" data-type="transaction" data-id="${t.id}">Modifier</button>
                        <button class="btn btn-sm btn-danger" data-action="delete" data-type="transaction" data-id="${t.id}">Supprimer</button>
                    </td>
                </tr>
            `;
        }).join('');

        listContainer.innerHTML = `
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Description</th>
                        <th>Type</th>
                        <th>Montant</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>${transactionRows}</tbody>
            </table>
        `;

    } catch (error) {
        console.error('❌ render.js: Erreur rendu finances:', error);
        listContainer.innerHTML = '<p class="error-message">Impossible de charger les transactions.</p>';
        window.app.showNotification('Erreur lors du chargement des finances', 'error');
    }
}


function renderSettings(user) {
    const section = document.getElementById('settings-section');
    if (!section) {
        console.error("L'élément #settings-section est introuvable.");
        return;
    }

    section.innerHTML = `
        <h2>Paramètres</h2>
        <div id="settings-content"></div>
    `;

    if (window.settingsUI && typeof window.settingsUI.showSettingsForm === 'function') {
        window.settingsUI.showSettingsForm(user);
    } else {
        console.error("❌ render.js: La fonction de rendu des paramètres (settingsUI.showSettingsForm) est introuvable.");
        const contentDiv = document.getElementById('settings-content');
        if(contentDiv) contentDiv.innerHTML = '<p class="error-message">Impossible de charger le module de paramètres.</p>';
        window.app.showNotification('Erreur au chargement des paramètres.', 'error');
    }
}

window.renderPublicContent = renderPublicContent;
window.renderDashboard = renderDashboard;
window.renderClients = renderClients;
window.renderCreations = renderCreations;
window.renderOrders = renderOrders;
window.renderMeasurements = renderMeasurements;
window.renderFinances = renderFinances;
window.renderSettings = renderSettings;