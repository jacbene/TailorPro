// modals.js - Gestion complète des modals avec la gestion d'images et l'historique client
console.log('🔧 modals.js: Chargement - Version avec historique client');

class ModalManager {
    constructor() {
        this.currentEditingId = null;
        this.init();
    }

    init() {
        console.log('🔧 modals.js: Initialisation Modal Manager');
        this._createModals();
        this.setupModalEvents(); // Les événements génériques sont déjà configurés
    }

    _createModals() {
        // ... (autres créations de modales)
        this._createClientHistoryModal(); // Ajout de la nouvelle modale
    }

    // ... (setupModalEvents, saveCreation, deleteItem, etc. restent les mêmes)

    /**
     * NOUVEAU : Ouvre la modale de l'historique des commandes d'un client.
     * @param {string} clientId L'ID du client.
     * @param {string} clientName Le nom complet du client.
     */
    async openClientHistoryModal(clientId, clientName) {
        const modal = document.getElementById('client-history-modal');
        const title = modal.querySelector('h3');
        const content = modal.querySelector('#client-history-content');

        if (!modal || !title || !content) return;

        title.textContent = `Historique pour ${clientName}`;
        content.innerHTML = '<p>Chargement de l'historique...</p>';
        this.openModal('client-history');

        try {
            const orders = await window.firebaseServices.orders.getOrdersByClientId(clientId);
            
            if (orders.length === 0) {
                content.innerHTML = '<p class="empty-state">Aucune commande trouvée pour ce client.</p>';
                return;
            }
            
            // Récupérer toutes les créations pour mapper les noms
            const creations = await window.firebaseServices.creations.getAll();
            const creationsMap = new Map(creations.map(c => [c.id, c.name]));

            content.innerHTML = `
                <ul class="order-history-list">
                    ${orders.map(order => `
                        <li>
                            <div class="order-history-item">
                                <span class="order-date">${window.app.formatDate(order.createdAt)}</span>
                                <span class="order-creation-name">${creationsMap.get(order.creationId) || 'Création supprimée'}</span>
                                <span class="order-amount">${window.app.formatCurrency(order.totalAmount)}</span>
                                <span class="status-badge status-${window.app.getStatusClass(order.status)}">${window.app.getStatusText(order.status)}</span>
                            </div>
                        </li>
                    `).join('')}
                </ul>
            `;

        } catch (error) {
            console.error('❌ modals.js: Erreur chargement historique client:', error);
            content.innerHTML = '<p class="text-error">Impossible de charger l'historique.</p>';
        }
    }

    // --- Section de création des modals HTML ---

    _createClientHistoryModal() {
        if (document.getElementById('client-history-modal')) return;
        const container = document.getElementById('modal-container');
        container.insertAdjacentHTML('beforeend', `
            <div id="client-history-modal" class="modal">
                <div class="modal-content large-modal">
                    <span class="close-modal">&times;</span>
                    <h3>Historique client</h3>
                    <div id="client-history-content">
                        <!-- Le contenu sera injecté dynamiquement -->
                    </div>
                </div>
            </div>
        `);
    }
    
    // ... (toutes les autres méthodes de création de modale restent ici)
}

document.addEventListener('DOMContentLoaded', () => {
    if (!window.modalManager) {
        window.modalManager = new ModalManager();
    }
});
