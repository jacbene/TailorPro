// js/firebase.js - Cœur Firebase : Initialisation et Authentification
console.log('🔥 firebase.js: Chargement du noyau Firebase');

const firebaseConfig = {
    apiKey: "AIzaSyC8kEnAiUh5aYPwEztHhgM9s89hjLE3uP0",
    authDomain: "taylorpro-85369071-9db57.firebaseapp.com",
    projectId: "taylorpro-85369071-9db57",
    storageBucket: "taylorpro-85369071-9db57.appspot.com",
    messagingSenderId: "609218281071",
    appId: "1:609218281071:web:026f1a985f80daddb7579a"
};

let auth = null;
let db = null;
let storage = null;
let ui = null; // Instance de FirebaseUI
let firebaseInitialized = false;
let authObserverUnsubscribe = null;

/**
 * Initialise Firebase et ses services de base.
 */
function initializeFirebase() {
    if (firebaseInitialized) return;

    try {
        if (!firebase.apps.length) {
            firebase.initializeApp(firebaseConfig);
        } else {
            firebase.app();
        }
        
        auth = firebase.auth();
        db = firebase.firestore();
        storage = firebase.storage();
        firebaseInitialized = true;

        // Attacher les services à l'objet global pour un accès facile
        window.firebaseServices.auth = auth;
        window.firebaseServices.firestore = db;
        window.firebaseServices.storage = storage;

        document.dispatchEvent(new CustomEvent('firebase-services-ready'));
        console.log('✅ firebase.js: Services Firebase (Auth, Firestore, Storage) prêts.');

    } catch (error) {
        console.error('❌ firebase.js: Erreur initialisation Firebase:', error);
    }
}

/**
 * NOUVEAU: Initialise l'interface utilisateur FirebaseUI.
 * @param {string} containerSelector - Le sélecteur CSS du conteneur où afficher l'UI.
 * @returns {boolean} - True si l'initialisation a réussi, sinon false.
 */
function initializeUI(containerSelector) {
    if (!auth) {
        console.error('❌ firebase.js: Auth doit être initialisé avant UI.');
        return false;
    }
    if (typeof firebaseui === 'undefined') {
        console.error('❌ firebase.js: Librairie FirebaseUI non chargée.');
        return false;
    }

    ui = firebaseui.auth.AuthUI.getInstance() || new firebaseui.auth.AuthUI(auth);

    const uiConfig = {
        callbacks: {
            signInSuccessWithAuthResult: function(authResult, redirectUrl) {
                console.log('✅ firebase.js: Connexion FirebaseUI réussie.', authResult);
                // On ne redirige pas, on gère via des événements.
                return false;
            },
            uiShown: function() {
                // L'interface est affichée.
            }
        },
        signInFlow: 'popup',
        signInSuccessUrl: '/',
        signInOptions: [
            firebase.auth.GoogleAuthProvider.PROVIDER_ID,
            firebase.auth.EmailAuthProvider.PROVIDER_ID,
        ],
        tosUrl: '/terms-of-service.html',
        privacyPolicyUrl: '/privacy-policy.html'
    };

    ui.start(containerSelector, uiConfig);
    console.log('✅ firebase.js: FirebaseUI démarré.');
    return true;
}

/**
 * NOUVEAU: Réinitialise l'état de FirebaseUI (utile à la déconnexion).
 */
function resetUI() {
    if (ui) {
        ui.reset();
        console.log('✅ firebase.js: FirebaseUI réinitialisé.');
    }
}


/**
 * Déconnecte l'utilisateur.
 */
async function signOut() {
    if (!auth) return;
    try {
        await auth.signOut();
        console.log('✅ firebase.js: Déconnexion réussie.');
    } catch (error) {
        console.error('❌ firebase.js: Erreur lors de la déconnexion:', error);
        throw error;
    }
}

/**
 * Active l'observateur d'état d'authentification.
 */
function enableAuthObserver(callback) {
    if (!auth) {
        console.error('❌ firebase.js: Firebase Auth n\'est pas initialisé.');
        return;
    }
    if (authObserverUnsubscribe) {
        authObserverUnsubscribe();
    }
    authObserverUnsubscribe = auth.onAuthStateChanged(callback);
    console.log('✅ firebase.js: Observateur d\'état d\'authentification activé.');
}

/**
 * Vérifie une session existante sans activer l'observateur permanent.
 * @returns {Promise<firebase.User|null>}
 */
function checkExistingSession() {
    return new Promise((resolve) => {
        if (!auth) return resolve(null);
        const unsubscribe = auth.onAuthStateChanged(user => {
            unsubscribe();
            resolve(user);
        });
    });
}


/**
 * Exige une authentification pour une action donnée.
 */
function requireAuth(action = 'cette action') {
    if (!auth || !auth.currentUser) {
        const message = `Veuillez vous connecter pour effectuer ${action}.`;
        document.dispatchEvent(new CustomEvent('auth-required', { detail: { action, message } }));
        throw new Error('Authentification requise.');
    }
    return auth.currentUser;
}

// --- Exposition des services via l'objet global --- //

window.firebaseServices = {
    // Initialisation
    initialize: initializeFirebase,
    isInitialized: () => firebaseInitialized,

    // Services de base (pour compatibilité)
    getAuth: () => auth,
    getFirestore: () => db,
    getStorage: () => storage,

    // Authentification
    enableAuthObserver: enableAuthObserver,
    checkExistingSession: checkExistingSession,
    requireAuth: requireAuth,
    signOut: signOut,
    getCurrentUser: () => auth ? auth.currentUser : null,

    // NOUVEAU: Interface Utilisateur
    initializeUI: initializeUI,
    resetUI: resetUI
};

console.log('✅ firebase.js: Noyau Firebase chargé et prêt à être initialisé.');
